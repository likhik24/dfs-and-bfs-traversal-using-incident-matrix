#include <stdio.h>
#include<stdlib.h>

int bubblesort(int[], int);
int main()
{
  

	
	

	int a[20],temp;
	int n,i,j,count=0;

	
	
	
	printf("enter numberof elements in array \n");
	scanf("%d",&n);
	printf("number of elements are %d\n",n);
	printf("elements before sorting are  ");
	
	for(i=0 ;i<n ;i++)
	{
		
	scanf("%d",&a[i]);

	printf("%d\t",a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0 ;j<n ;j++)
		{
			if(a[j]>a[j+1])
			{
			  temp=a[j];
			  a[j]=a[j+1];
			  a[j+1]=temp;
			}
		
			
			  
		}
		
	
	     count++;
	       
	       
	      printf("\nelements after %d  pass are ",count);
	       for( j=0;j<n;j++)
	       {
	       
		printf("%d\t",a[j]);
	       }
		
	}
printf("\nelements after sorting are ");
for(i=0;i<n;i++)
printf("%d\t",a[i]);
}
