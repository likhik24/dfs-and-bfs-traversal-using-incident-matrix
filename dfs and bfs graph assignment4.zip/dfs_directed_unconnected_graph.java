package assignment1;

public class dfs_directed_unconnected_graph {
	int arr[][]={{1,0,1,-1,0,0,0,0,1,1,-1,0,0,0,0},
	        {0,0,0,1,-1,-1,0,0,0,0,0,0,0,0,0},
	        {-1,1,0,0,1,0,0,0,0,0,0,0,0,0,0},
	        {0,1,-1,0,0,1,0,0,0,0,0,0,0,0,0},
	        {0,0,0,0,0,0,0,1,-1,1,0,0,0,0,0},
	        {0,0,0,0,0,0,0,-1,0,0,0,0,1,1,0},
	        {0,0,0,0,0,0,0,0,0,0,0,0,0,-1,1},
	        {0,0,0,0,0,0,1,0,0,-1,0,1,0,0,0},
	        {0,0,0,0,0,0,1,0,1,0,-1,0,0,0,0},
	        {0,0,0,0,0,0,0,0,0,0,1,-1,-1,0,-1}
	        };
	int[] visited = new int[9];
	private int temp;
		
		public void Dfs(int node)
		{
			visited[node]=1;
			System.out.println(node);
			for(int j=0;j<=14;j++)
			{
				   if(arr[node][j]==1 )
				    {
					   temp=j;
					   int k = FindAdj(temp,node);
					   if(visited[k]==0){
						   Dfs(k);
					   }
				    }
			}
		}
		
		public int FindAdj(int num,int k)
		{
			for(int i=0;i<=9;i++)
			{
				
				if(arr[i][num]==-1  && i!=k)
				
				return i;
			}
			return k;
			
		}
		
		public static void main(String[] args) {
			
			
			Dfs_directed_graph potti=new Dfs_directed_graph() ;
			potti.Dfs(6);
			System.out.println("DFS directed unconnected graph");

			
		}
	}

