package assignment1;

import java.util.LinkedList;
import java.util.Queue;

public class BFS_directed_graph {
	static int arr[][]={{1,0,1,-1,0,0,0,0,1,1,-1,0,0,0,0},
        {0,0,0,1,-1,-1,-1,0,0,0,0,0,0,0,0},
        {-1,1,0,0,1,0,0,0,0,0,0,0,0,0,0},
        {0,0,-1,0,0,1,0,0,0,0,0,0,0,0,0},
        {0,-1,0,0,0,0,0,1,-1,1,0,0,0,0,0},
        {0,0,0,0,0,0,0,-1,0,0,0,0,1,1,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,-1,1},
        {0,0,0,0,0,0,0,0,0,-1,0,1,0,0,0},
        {0,0,0,0,0,0,1,0,1,0,-1,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,1,-1,-1,0,-1}
        };
	     
static boolean[] visited1 = new boolean[9];
//private int temp;
public static int FindAdj(int num,int k)
{
	for(int i=0;i<10;i++)
	{
		
		if(arr[i][num]==-1  && i!=k)
		
		return i;
	}
	return k;
	
}
public static void graphBFS(int k){
	Queue<Integer> queue = new LinkedList<Integer>();
	queue.add(k);
	visited1[k]=true;
	while(!queue.isEmpty()){
		int k1 = queue.remove();
		System.out.println(k1);
		for(int e =0;e<15;e++){
			if(arr[k1][e]==1){
				int i =FindAdj(k1, e);
				if(!visited1[i]){
					queue.add(i);
					visited1[i] = true;
				}
			}
		}
	}
}
public static void main(String[] args) {
	
	//BFS_directed_graph potti=new BFS_directed_graph() ;
	graphBFS(2);
	System.out.println("BFS directed connected graph");

	
}
}

	
