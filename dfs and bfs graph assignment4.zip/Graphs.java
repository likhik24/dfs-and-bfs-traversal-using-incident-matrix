package assignment1;

import java.util.LinkedList;
import java.util.Queue;

public class Graphs {
	public static int[][] incidentMatrix = new int[10][15];
	public static boolean[] visited1= new boolean[10];
	public static boolean[] visited= new boolean[10];
	
	public static void main(String[] args){
		
		createGraph();
		    for(int v=0;v<10;v++)
		        {
			    if(visited[v]==false)
				    {
			    	System.out.println("visited Dfs traversal of undirected connected graph is");
			    	graphDFS(v);
			    	
			        }
		        }
			for(int k=0;k<10;k++)
				{
				if(visited1[k]==false)
					{
					System.out.println("visited Bfs traversal of undirected connected graph is");
					graphBFS(k);
					
					}
				}
			
		
		
	}
	
	public static void createGraph(){
		incidentMatrix[0][0]=1;
		incidentMatrix[0][1]=1;
		incidentMatrix[0][8]=1;
		incidentMatrix[1][0]=1;
		incidentMatrix[1][2]=1;
		incidentMatrix[1][3]=1;
		incidentMatrix[1][10]=1;
		incidentMatrix[2][2]=1;
		incidentMatrix[2][6]=1;
		incidentMatrix[2][11]=1;
		incidentMatrix[3][1]=1;
		incidentMatrix[3][5]=1;
		incidentMatrix[3][7]=1;
		incidentMatrix[3][14]=1;
		incidentMatrix[4][3]=1;
		incidentMatrix[4][4]=1;
		incidentMatrix[4][14]=1;
		incidentMatrix[5][4]=1;
		incidentMatrix[5][5]=1;
		incidentMatrix[5][6]=1;
		incidentMatrix[5][13]=1;
		incidentMatrix[6][7]=1;
		incidentMatrix[6][9]=1;
		incidentMatrix[6][12]=1;
		incidentMatrix[7][8]=1;
		incidentMatrix[7][9]=1;
		incidentMatrix[8][10]=1;
		incidentMatrix[8][11]=1;
		incidentMatrix[9][12]=1;
		incidentMatrix[9][13]=1;
	}
	public static void graphDFS(int v){
		if(visited[v]==false){
			System.out.println(v);
			visited[v]=true;
			for(int e =0;e<15;e++){
				if(incidentMatrix[v][e]==1){
					graphDFS(findAdj(v,e));
				}
			}
		}	
	}
	public static int findAdj(int v, int e){
		int vertix=v;
		for(int v_i=0;v_i<10;v_i++){
			if(incidentMatrix[v_i][e]==1 && v_i!=v){
				vertix = v_i;
				break;
			}
		}
		return vertix;
	}

	public static void graphBFS(int k){
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(k);
		visited1[k]=true;
		while(!queue.isEmpty()){
			int k1 = queue.remove();
			System.out.println(k1);
			for(int e =0;e<15;e++){
				if(incidentMatrix[k1][e]==1){
					int i =findAdj(k1, e);
					if(!visited1[i]){
						queue.add(i);
						visited1[i] = true;
					}
				}
			}
		}
	}
}
